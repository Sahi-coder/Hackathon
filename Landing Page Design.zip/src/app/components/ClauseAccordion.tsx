import { ChevronDown } from "lucide-react";
import { motion } from "motion/react";
import { useState } from "react";
import { useLanguage } from "../utils/LanguageContext";

interface Clause {
  category: string;
  items: string[];
}

interface ClauseAccordionProps {
  clauses: Clause[];
}

export function ClauseAccordion({ clauses }: ClauseAccordionProps) {
  const { t } = useLanguage();
  const [expandedIndex, setExpandedIndex] = useState<number | null>(0);

  return (
    <div className="bg-white rounded-2xl shadow-lg p-8">
      <h2 className="text-2xl font-bold text-[#1E3A8A] mb-6">
        {t("keyFindings")}
      </h2>
      <div className="space-y-4">
        {clauses.map((clause, index) => (
          <div
            key={index}
            className="border-2 border-gray-200 rounded-xl overflow-hidden"
          >
            <button
              onClick={() =>
                setExpandedIndex(expandedIndex === index ? null : index)
              }
              className="w-full flex items-center justify-between p-4 hover:bg-gray-50 transition-colors"
            >
              <span className="font-semibold text-[#1E3A8A]">
                {t(clause.category as any)}
              </span>
              <motion.div
                animate={{ rotate: expandedIndex === index ? 180 : 0 }}
                transition={{ duration: 0.3 }}
              >
                <ChevronDown className="w-5 h-5 text-gray-600" />
              </motion.div>
            </button>

            {expandedIndex === index && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.3 }}
                className="border-t-2 border-gray-200"
              >
                <div className="p-4 space-y-3 bg-gray-50">
                  {clause.items.map((item, itemIndex) => (
                    <motion.div
                      key={itemIndex}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: itemIndex * 0.1 }}
                      className="p-3 bg-white rounded-lg border border-gray-200"
                    >
                      <p className="text-sm text-gray-700 italic">\"{t(item as any)}\"</p>
                    </motion.div>
                  ))}
                </div>
              </motion.div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}