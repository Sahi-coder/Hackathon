import { useState } from "react";
import { useNavigate } from "react-router";
import { ArrowRight, AlertCircle, Link as LinkIcon, FileText, Upload, Globe } from "lucide-react";
import { LoadingState } from "./LoadingState";
import { motion } from "motion/react";
import { useLanguage } from "../utils/LanguageContext";
import { Language } from "../utils/translations";

type InputMode = "url" | "pdf" | "text";

const languages = [
  { code: "en", name: "English", flag: "🇬🇧" },
  { code: "ta", name: "தமிழ்", flag: "🇮🇳" },
];

export function InputForm() {
  const { language, setLanguage } = useLanguage();
  const [mode, setMode] = useState<InputMode>("url");
  const [url, setUrl] = useState("");
  const [text, setText] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    // Validation based on mode
    if (mode === "url") {
      if (!url.trim()) {
        setError("Please enter a valid URL");
        return;
      }
      try {
        new URL(url);
      } catch {
        setError("Please enter a valid URL");
        return;
      }
    } else if (mode === "pdf") {
      if (!file) {
        setError("Please upload a PDF file");
        return;
      }
      if (file.type !== "application/pdf") {
        setError("Please upload a valid PDF file");
        return;
      }
    } else if (mode === "text") {
      if (!text.trim()) {
        setError("Please enter some text to analyze");
        return;
      }
      if (text.trim().length < 100) {
        setError("Please enter at least 100 characters");
        return;
      }
    }

    setLoading(true);

    // Simulate analysis process
    setTimeout(() => {
      const analysisId = Math.random().toString(36).substring(7);
      navigate(`/dashboard/${analysisId}`);
    }, 4000);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      if (selectedFile.type === "application/pdf") {
        setFile(selectedFile);
        setError("");
      } else {
        setError("Please upload a PDF file");
        setFile(null);
      }
    }
  };

  if (loading) {
    return <LoadingState />;
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="w-full max-w-2xl"
    >
      <div className="bg-white rounded-2xl shadow-xl p-8 md:p-12">
        <h1 className="text-3xl md:text-4xl font-bold text-[#1E3A8A] text-center mb-4">
          Analyze a Privacy Policy
        </h1>
        <p className="text-gray-600 text-center mb-8">
          Choose your preferred input method below
        </p>

        {/* Tab Navigation */}
        <div className="flex space-x-2 mb-8 bg-gray-100 p-1 rounded-xl">
          <button
            type="button"
            onClick={() => {
              setMode("url");
              setError("");
            }}
            className={`flex-1 flex items-center justify-center space-x-2 px-4 py-3 rounded-lg font-semibold transition-all ${
              mode === "url"
                ? "bg-white text-[#1E3A8A] shadow-md"
                : "text-gray-600 hover:text-[#1E3A8A]"
            }`}
          >
            <LinkIcon className="w-4 h-4" />
            <span>URL</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setMode("pdf");
              setError("");
            }}
            className={`flex-1 flex items-center justify-center space-x-2 px-4 py-3 rounded-lg font-semibold transition-all ${
              mode === "pdf"
                ? "bg-white text-[#1E3A8A] shadow-md"
                : "text-gray-600 hover:text-[#1E3A8A]"
            }`}
          >
            <Upload className="w-4 h-4" />
            <span>PDF</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setMode("text");
              setError("");
            }}
            className={`flex-1 flex items-center justify-center space-x-2 px-4 py-3 rounded-lg font-semibold transition-all ${
              mode === "text"
                ? "bg-white text-[#1E3A8A] shadow-md"
                : "text-gray-600 hover:text-[#1E3A8A]"
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>Text</span>
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Language Selector */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              <Globe className="w-4 h-4 inline mr-2" />
              Analysis Language
            </label>
            <select
              value={language}
              onChange={(e) => setLanguage(e.target.value as Language)}
              className="w-full px-6 py-4 text-lg border-2 border-gray-200 rounded-xl focus:border-[#1E3A8A] focus:outline-none transition-colors bg-white cursor-pointer"
            >
              {languages.map((lang) => (
                <option key={lang.code} value={lang.code}>
                  {lang.flag} {lang.name}
                </option>
              ))}
            </select>
            <p className="mt-2 text-sm text-gray-500">
              Select the language for your analysis results
            </p>
          </motion.div>

          {/* URL Input */}
          {mode === "url" && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Policy URL
              </label>
              <input
                type="text"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                placeholder="https://example.com/privacy-policy"
                className="w-full px-6 py-4 text-lg border-2 border-gray-200 rounded-xl focus:border-[#1E3A8A] focus:outline-none transition-colors"
              />
            </motion.div>
          )}

          {/* PDF Upload */}
          {mode === "pdf" && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Upload PDF Document
              </label>
              <div className="relative">
                <input
                  type="file"
                  accept=".pdf"
                  onChange={handleFileChange}
                  className="hidden"
                  id="pdf-upload"
                />
                <label
                  htmlFor="pdf-upload"
                  className="flex flex-col items-center justify-center w-full px-6 py-12 border-2 border-dashed border-gray-300 rounded-xl hover:border-[#1E3A8A] transition-colors cursor-pointer bg-gray-50 hover:bg-gray-100"
                >
                  <Upload className="w-12 h-12 text-gray-400 mb-4" />
                  <span className="text-lg font-semibold text-gray-700 mb-2">
                    {file ? file.name : "Click to upload PDF"}
                  </span>
                  <span className="text-sm text-gray-500">
                    Maximum file size: 10MB
                  </span>
                </label>
              </div>
            </motion.div>
          )}

          {/* Text Input */}
          {mode === "text" && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Paste Policy Text
              </label>
              <textarea
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="Paste the privacy policy or terms of service text here..."
                rows={12}
                className="w-full px-6 py-4 text-base border-2 border-gray-200 rounded-xl focus:border-[#1E3A8A] focus:outline-none transition-colors resize-none"
              />
              <div className="mt-2 text-sm text-gray-500 text-right">
                {text.length} characters (minimum 100)
              </div>
            </motion.div>
          )}

          {error && (
            <div className="flex items-center space-x-2 text-[#EF4444] bg-red-50 p-4 rounded-lg">
              <AlertCircle className="w-5 h-5 flex-shrink-0" />
              <span className="text-sm font-semibold">{error}</span>
            </div>
          )}

          <motion.button
            type="submit"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="w-full bg-[#1E3A8A] text-white px-8 py-4 rounded-xl text-lg font-semibold hover:bg-[#1e40af] transition-colors flex items-center justify-center space-x-2 shadow-lg"
          >
            <span>Analyze Now</span>
            <ArrowRight className="w-5 h-5" />
          </motion.button>
        </form>

        {/* Example URLs (only show for URL mode) */}
        {mode === "url" && (
          <div className="mt-8 pt-8 border-t border-gray-200">
            <p className="text-sm text-gray-500 text-center mb-4">
              Try these examples:
            </p>
            <div className="flex flex-wrap gap-2 justify-center">
              {[
                "https://twitter.com/privacy",
                "https://facebook.com/policy",
                "https://google.com/policies/terms",
              ].map((exampleUrl) => (
                <button
                  key={exampleUrl}
                  type="button"
                  onClick={() => setUrl(exampleUrl)}
                  className="px-4 py-2 text-sm bg-[#F9FAFB] text-gray-600 rounded-lg hover:bg-gray-200 transition-colors"
                >
                  {exampleUrl.split("/")[2]}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </motion.div>
  );
}