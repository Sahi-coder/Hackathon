import { Link, useLocation } from "react-router";
import { Scale, Menu } from "lucide-react";
import { useState } from "react";

export function Navbar() {
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const isActive = (path: string) => {
    return location.pathname === path;
  };

  return (
    <nav className="bg-[#1E3A8A] border-b border-[#163470] sticky top-0 z-50 shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-2 group">
            <div className="bg-white p-2 rounded-lg group-hover:bg-gray-100 transition-colors">
              <Scale className="w-5 h-5 text-[#1E3A8A]" />
            </div>
            <span className="text-xl font-bold text-white">PolicyLens</span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-6">
            <Link
              to="/"
              className={`transition-colors ${
                isActive("/")
                  ? "text-white font-semibold"
                  : "text-gray-200 hover:text-white"
              }`}
            >
              Home
            </Link>
            <Link
              to="/analyze"
              className={`transition-colors ${
                isActive("/analyze")
                  ? "text-white font-semibold"
                  : "text-gray-200 hover:text-white"
              }`}
            >
              Analyze
            </Link>
            <Link
              to="/history"
              className={`transition-colors ${
                isActive("/history")
                  ? "text-white font-semibold"
                  : "text-gray-200 hover:text-white"
              }`}
            >
              History
            </Link>
            <Link
              to="/analyze"
              className="bg-white text-[#1E3A8A] px-5 py-2 rounded-lg hover:bg-gray-100 transition-colors font-semibold"
            >
              Try Now
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden text-white"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            <Menu className="w-6 h-6" />
          </button>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden py-4 space-y-2">
            <Link
              to="/"
              className="block px-4 py-2 text-gray-200 hover:bg-[#163470] rounded-lg"
              onClick={() => setMobileMenuOpen(false)}
            >
              Home
            </Link>
            <Link
              to="/analyze"
              className="block px-4 py-2 text-gray-200 hover:bg-[#163470] rounded-lg"
              onClick={() => setMobileMenuOpen(false)}
            >
              Analyze
            </Link>
            <Link
              to="/history"
              className="block px-4 py-2 text-gray-200 hover:bg-[#163470] rounded-lg"
              onClick={() => setMobileMenuOpen(false)}
            >
              History
            </Link>
            <Link
              to="/analyze"
              className="block px-4 py-2 bg-white text-[#1E3A8A] rounded-lg hover:bg-gray-100 text-center font-semibold"
              onClick={() => setMobileMenuOpen(false)}
            >
              Try Now
            </Link>
          </div>
        )}
      </div>
    </nav>
  );
}