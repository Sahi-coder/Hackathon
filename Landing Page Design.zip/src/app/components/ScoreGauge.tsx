import { motion } from "motion/react";
import { useLanguage } from "../utils/LanguageContext";

interface ScoreGaugeProps {
  score: number;
  risk: string;
}

export function ScoreGauge({ score, risk }: ScoreGaugeProps) {
  const { t } = useLanguage();
  
  const getColor = () => {
    if (score >= 80) return "#10B981";
    if (score >= 60) return "#F59E0B";
    return "#EF4444";
  };

  const getRiskColor = () => {
    if (score >= 80) return "text-[#10B981]";
    if (score >= 60) return "text-[#F59E0B]";
    return "text-[#EF4444]";
  };

  const color = getColor();
  const circumference = 2 * Math.PI * 70;
  const strokeDashoffset = circumference - (score / 100) * circumference;

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      className="bg-white rounded-2xl shadow-lg p-8"
    >
      <h2 className="text-xl font-bold text-[#1E3A8A] mb-6">{t("overallRiskScore")}</h2>
      <div className="flex flex-col items-center">
        {/* Circular Gauge */}
        <div className="relative w-48 h-48 mb-6">
          <svg className="transform -rotate-90" width="192" height="192">
            {/* Background circle */}
            <circle
              cx="96"
              cy="96"
              r="70"
              stroke="#E5E7EB"
              strokeWidth="12"
              fill="none"
            />
            {/* Progress circle */}
            <motion.circle
              cx="96"
              cy="96"
              r="70"
              stroke={color}
              strokeWidth="12"
              fill="none"
              strokeLinecap="round"
              initial={{ strokeDashoffset: circumference }}
              animate={{ strokeDashoffset }}
              transition={{ duration: 1.5, ease: "easeOut" }}
              style={{
                strokeDasharray: circumference,
              }}
            />
          </svg>
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center">
              <div className={`text-5xl font-bold ${getRiskColor()}`}>
                {score}%
              </div>
            </div>
          </div>
        </div>
        <p className={`text-2xl font-semibold ${getRiskColor()}`}>{risk}</p>
      </div>
    </motion.div>
  );
}