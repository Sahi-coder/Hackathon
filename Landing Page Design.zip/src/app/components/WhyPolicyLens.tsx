import { Check } from "lucide-react";
import { motion } from "motion/react";

const features = [
  "Risk Scoring",
  "Visual Dashboard",
  "Clause Breakdown",
  "Transparent Analysis",
];

export function WhyPolicyLens() {
  return (
    <section className="py-20 px-4 bg-gradient-to-br from-[#1E3A8A]/5 to-transparent">
      <div className="max-w-4xl mx-auto text-center">
        <h2 className="text-4xl font-bold text-[#1E3A8A] mb-12">
          Why PolicyLens?
        </h2>
        <div className="grid md:grid-cols-2 gap-6">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="bg-white rounded-xl p-6 flex items-center space-x-4 shadow-md"
            >
              <div className="bg-[#10B981] rounded-full p-2">
                <Check className="w-6 h-6 text-white" />
              </div>
              <span className="text-lg font-semibold text-gray-800">
                {feature}
              </span>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
