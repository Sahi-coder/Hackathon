import { AlertCircle, AlertTriangle, CheckCircle } from "lucide-react";
import { motion } from "motion/react";
import { useLanguage } from "../utils/LanguageContext";

interface Category {
  name: string;
  score: number;
  risk: string;
  impact: number;
}

interface RiskCardProps {
  category: Category;
}

export function RiskCard({ category }: RiskCardProps) {
  const { t } = useLanguage();
  
  const getRiskIcon = () => {
    if (category.risk === "High") {
      return <AlertCircle className="w-6 h-6 text-[#EF4444]" />;
    }
    if (category.risk === "Moderate") {
      return <AlertTriangle className="w-6 h-6 text-[#F59E0B]" />;
    }
    return <CheckCircle className="w-6 h-6 text-[#10B981]" />;
  };

  const getRiskColor = () => {
    if (category.risk === "High") return "text-[#EF4444] bg-[#EF4444]/10";
    if (category.risk === "Moderate")
      return "text-[#F59E0B] bg-[#F59E0B]/10";
    return "text-[#10B981] bg-[#10B981]/10";
  };

  const getBorderColor = () => {
    if (category.risk === "High") return "border-[#EF4444]";
    if (category.risk === "Moderate") return "border-[#F59E0B]";
    return "border-[#10B981]";
  };

  return (
    <motion.div
      whileHover={{ y: -5, boxShadow: "0 10px 30px rgba(0,0,0,0.15)" }}
      className={`bg-white rounded-xl p-6 border-2 ${getBorderColor()} transition-all`}
    >
      <div className="flex items-start justify-between mb-4">
        <h3 className="text-lg font-bold text-[#1E3A8A]">{t(category.name as any) || category.name}</h3>
        {getRiskIcon()}
      </div>

      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-sm text-gray-600">Risk Level:</span>
          <span
            className={`px-3 py-1 rounded-full text-sm font-semibold ${getRiskColor()}`}
          >
            {category.risk}
          </span>
        </div>

        <div className="flex items-center justify-between">
          <span className="text-sm text-gray-600">Score:</span>
          <span className="text-lg font-bold text-[#1E3A8A]">
            {category.score}%
          </span>
        </div>

        <div className="flex items-center justify-between">
          <span className="text-sm text-gray-600">Score Impact:</span>
          <span className="text-sm font-semibold text-gray-800">
            {category.impact > 0 ? "+" : ""}
            {category.impact}
          </span>
        </div>
      </div>
    </motion.div>
  );
}