import { AlertTriangle, AlertCircle } from "lucide-react";
import { motion } from "motion/react";

interface AlertBoxProps {
  alerts: string[];
}

export function AlertBox({ alerts }: AlertBoxProps) {
  if (alerts.length === 0) {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white rounded-2xl shadow-lg p-8"
      >
        <h2 className="text-xl font-bold text-[#1E3A8A] mb-6">Risk Alerts</h2>
        <div className="flex items-center space-x-3 p-4 bg-[#10B981]/10 border-2 border-[#10B981] rounded-xl">
          <AlertCircle className="w-6 h-6 text-[#10B981]" />
          <p className="text-[#10B981] font-semibold">
            No critical risks detected
          </p>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      className="bg-white rounded-2xl shadow-lg p-8"
    >
      <h2 className="text-xl font-bold text-[#1E3A8A] mb-6">Risk Alerts</h2>
      <div className="space-y-4">
        {alerts.map((alert, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
            className="flex items-start space-x-3 p-4 bg-[#EF4444]/10 border-2 border-[#EF4444] rounded-xl"
          >
            <AlertTriangle className="w-6 h-6 text-[#EF4444] flex-shrink-0 mt-0.5" />
            <p className="text-[#EF4444] font-medium">{alert}</p>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
}
