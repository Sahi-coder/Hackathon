import { motion, AnimatePresence } from "motion/react";
import { CheckCircle, AlertTriangle, Facebook, ShoppingCart, MessageCircle, BookOpen, Youtube, GraduationCap, MessageSquare, X } from "lucide-react";
import { useState } from "react";

interface Platform {
  name: string;
  icon: JSX.Element;
  score: number;
  color: string;
  badge: string;
  highlights: Array<{
    text: string;
    type: "warning" | "check";
  }>;
  fullDetails: string;
}

const platforms: Platform[] = [
  {
    name: "Facebook",
    icon: <Facebook className="w-8 h-8 text-blue-600" />,
    score: 3,
    color: "bg-[#EF4444]",
    badge: "SCORE: 3",
    highlights: [
      { text: "Facebook stores your data whether you have an account or not.", type: "warning" },
      { text: "Facebook can use your data for advertising.", type: "warning" },
      { text: "Deleted content is not really deleted.", type: "warning" },
      { text: "Tracking opt-out only stops data sales, not targeting.", type: "warning" },
      { text: "This service could track you on other websites.", type: "warning" },
    ],
    fullDetails: "Facebook has extensive data collection practices including storing user data even for non-account holders. The platform uses personal information for targeted advertising and shares data with third-party partners. Deleted content may remain in backup systems, and tracking opt-out features are limited in scope. Facebook employs cross-site tracking technologies and maintains detailed user profiles for advertising purposes.",
  },
  {
    name: "Amazon",
    icon: <ShoppingCart className="w-8 h-8 text-orange-600" />,
    score: 2,
    color: "bg-[#EF4444]",
    badge: "SCORE: 2",
    highlights: [
      { text: "This service collects an account for advertising.", type: "warning" },
      { text: "They can use your personal info when advertisers submit you.", type: "warning" },
      { text: "The service can delete your account without prior notice and without a reason.", type: "warning" },
      { text: "This service tracks you on other websites.", type: "warning" },
    ],
    fullDetails: "Amazon collects extensive user data for advertising and personalization purposes. The platform reserves the right to terminate accounts without prior notice or explanation. Amazon's tracking extends beyond its own platform to third-party websites through various tracking technologies. User data may be shared with advertisers and business partners, and the company maintains detailed purchase histories and browsing patterns.",
  },
  {
    name: "Reddit",
    icon: <MessageCircle className="w-8 h-8 text-orange-500" />,
    score: 1,
    color: "bg-[#EF4444]",
    badge: "SCORE: 1",
    highlights: [
      { text: "Reddit may record audio.", type: "warning" },
      { text: "Tracking opt-out targeting cookies for other purposes without your consent.", type: "warning" },
      { text: "This service tracks which web page brought you to it.", type: "warning" },
      { text: "This service may use tracking pixels/web beacons.", type: "warning" },
      { text: "The service may license access to collect its device parties.", type: "warning" },
    ],
    fullDetails: "Reddit has comprehensive data collection policies including potential audio recording capabilities. The platform uses tracking pixels, web beacons, and referrer tracking to monitor user behavior. Opt-out options for tracking are limited and may not prevent all forms of data collection. Reddit may license user data to third parties and maintains detailed activity logs across the platform.",
  },
  {
    name: "Wikipedia",
    icon: <BookOpen className="w-8 h-8 text-gray-700" />,
    score: 8,
    color: "bg-[#10B981]",
    badge: "SCORE: 8",
    highlights: [
      { text: "Wikimedia discloses statistics in the right to get info about you.", type: "check" },
      { text: "No special access needed for user info.", type: "check" },
      { text: "Deletion does need your request for your information when allowed by law.", type: "check" },
      { text: "Archives of text agreements are provided so their changes on your request can be reviewed.", type: "check" },
      { text: "Information is protected about how they collect personal data.", type: "check" },
      { text: "Good feedback is a better repository changes to its terms.", type: "check" },
    ],
    fullDetails: "Wikipedia (Wikimedia Foundation) maintains strong privacy protections and transparency. Users have clear rights to access and delete their personal information. The platform provides archives of all policy changes and accepts community feedback on terms of service modifications. Data collection is minimal and clearly disclosed, with no personalized advertising or extensive tracking.",
  },
  {
    name: "YouTube",
    icon: <Youtube className="w-8 h-8 text-red-600" />,
    score: 2,
    color: "bg-[#EF4444]",
    badge: "SCORE: 2",
    highlights: [
      { text: "The service collects your IP address for business use.", type: "warning" },
    ],
    fullDetails: "YouTube, as part of Google, collects extensive user data including IP addresses, viewing history, search queries, and device information. This data is used for personalized advertising, content recommendations, and business analytics. YouTube tracks user behavior across Google services and third-party websites through various tracking technologies. The platform shares data with advertisers and content creators.",
  },
  {
    name: "Duolingo",
    icon: <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center text-white font-bold">D</div>,
    score: 6,
    color: "bg-[#F59E0B]",
    badge: "SCORE: 6",
    highlights: [
      { text: "Instead of asking directly, this Service will assume your consent when you from your online activity.", type: "warning" },
      { text: "No need to register.", type: "check" },
      { text: "You can delete your account and Duolingo deletes your data.", type: "check" },
      { text: "This service provides an online way accessible even for browser users.", type: "check" },
      { text: "This service cannot refund charges to its terms without your consent.", type: "warning" },
      { text: "The service must your prior approval to it terms, policies or data.", type: "check" },
    ],
    fullDetails: "Duolingo collects learning data and progress information to personalize educational content. The platform assumes consent through usage but allows account deletion with data removal. Users can access the service without extensive registration requirements. However, implied consent mechanisms and changes to terms may not always require explicit user approval. The platform shares aggregated data for research purposes.",
  },
  {
    name: "Khan Academy",
    icon: <GraduationCap className="w-8 h-8 text-green-600" />,
    score: 7,
    color: "bg-[#F59E0B]",
    badge: "SCORE: 7",
    highlights: [
      { text: "Your public contributions are used without your consent and without attribution.", type: "warning" },
      { text: "Tracking opt-out targeting cookies for other purposes without your consent.", type: "warning" },
      { text: "This service collects many different types of personal data.", type: "warning" },
      { text: "IP addresses may be collected and stored.", type: "warning" },
      { text: "No data is shared with third parties by default.", type: "check" },
      { text: "The service lets you delete your account without prior notice and without a reason.", type: "check" },
    ],
    fullDetails: "Khan Academy collects educational data to improve learning experiences but maintains relatively strong privacy protections. The platform doesn't share personal data with third parties by default and allows easy account deletion. However, public contributions may be used without attribution, and various tracking technologies are employed. IP addresses and learning patterns are collected for analytics purposes.",
  },
  {
    name: "Quora",
    icon: <MessageSquare className="w-8 h-8 text-red-700" />,
    score: 3,
    color: "bg-[#EF4444]",
    badge: "SCORE: 3",
    highlights: [
      { text: "Quora can delete or suspend your account if you don't post while we wait.", type: "warning" },
      { text: "The service may keep personal data even after a request for secure deletion from third parties at least data sharing.", type: "warning" },
      { text: "Tracking opt-out targets cookies for other purposes including non-tracking.", type: "warning" },
      { text: "This service tracks you on other websites.", type: "warning" },
      { text: "This service collects information about you from different sources through their API uses.", type: "warning" },
    ],
    fullDetails: "Quora maintains extensive data collection practices including cross-site tracking and third-party data aggregation. The platform may retain personal data even after deletion requests and can suspend accounts for inactivity. User contributions are tracked across the platform and linked to detailed user profiles. Data may be shared with third parties for advertising and analytics purposes.",
  },
];

function PlatformCard({ platform, onViewDetails }: { platform: Platform; onViewDetails: () => void }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className="bg-white rounded-xl shadow-md border border-gray-200 p-6 space-y-4"
    >
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          {platform.icon}
          <h3 className="text-lg font-bold text-gray-900">{platform.name}</h3>
        </div>
        <div className={`${platform.color} text-white px-3 py-1 rounded-md text-xs font-bold`}>
          {platform.badge}
        </div>
      </div>

      {/* Highlights */}
      <div className="space-y-2">
        {platform.highlights.slice(0, 3).map((highlight, index) => (
          <div key={index} className={`flex items-start space-x-2 p-2 rounded-lg ${
            highlight.type === "check" ? "bg-green-50" : 
            highlight.type === "warning" ? "bg-red-50" : "bg-yellow-50"
          }`}>
            {highlight.type === "check" ? (
              <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
            ) : (
              <AlertTriangle className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
            )}
            <p className="text-xs text-gray-700 leading-tight">{highlight.text}</p>
          </div>
        ))}
      </div>

      {/* Buttons */}
      <div className="flex items-center space-x-3 pt-2">
        <button 
          onClick={onViewDetails}
          className="flex-1 bg-[#1E3A8A] text-white px-4 py-2 rounded-lg font-semibold text-sm hover:bg-[#1e40af] transition-colors"
        >
          View Details
        </button>
      </div>
    </motion.div>
  );
}

function DetailModal({ platform, onClose }: { platform: Platform; onClose: () => void }) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.9, y: 20 }}
        className="bg-white rounded-2xl shadow-2xl max-w-3xl w-full max-h-[80vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="sticky top-0 bg-white border-b border-gray-200 p-6 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            {platform.icon}
            <div>
              <h2 className="text-2xl font-bold text-gray-900">{platform.name}</h2>
              <div className={`${platform.color} text-white px-3 py-1 rounded-md text-xs font-bold inline-block mt-1`}>
                {platform.badge}
              </div>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700 p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* Full Details */}
          <div>
            <h3 className="text-lg font-bold text-gray-900 mb-3">Detailed Analysis</h3>
            <p className="text-gray-700 leading-relaxed">{platform.fullDetails}</p>
          </div>

          {/* All Highlights */}
          <div>
            <h3 className="text-lg font-bold text-gray-900 mb-3">Key Findings</h3>
            <div className="space-y-2">
              {platform.highlights.map((highlight, index) => (
                <div key={index} className={`flex items-start space-x-2 p-3 rounded-lg ${
                  highlight.type === "check" ? "bg-green-50" : "bg-red-50"
                }`}>
                  {highlight.type === "check" ? (
                    <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                  ) : (
                    <AlertTriangle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
                  )}
                  <p className="text-sm text-gray-700">{highlight.text}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Action Button */}
          <div className="flex justify-end space-x-3 pt-4">
            <button
              onClick={onClose}
              className="px-6 py-2 border border-gray-300 text-gray-700 rounded-lg font-semibold hover:bg-gray-50 transition-colors"
            >
              Close
            </button>
            <a
              href="/analyze"
              className="px-6 py-2 bg-[#1E3A8A] text-white rounded-lg font-semibold hover:bg-[#1e40af] transition-colors"
            >
              Analyze Your Policy
            </a>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}

export function PlatformShowcase() {
  const [selectedPlatform, setSelectedPlatform] = useState<Platform | null>(null);

  return (
    <section className="py-20 px-4 bg-gradient-to-b from-gray-50 to-white">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Real Policy Analysis Examples
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            See how PolicyLens evaluates privacy policies from popular platforms
          </p>
        </motion.div>

        {/* Platform Grid */}
        <div className="grid md:grid-cols-2 gap-6">
          {platforms.map((platform, index) => (
            <PlatformCard 
              key={index} 
              platform={platform}
              onViewDetails={() => setSelectedPlatform(platform)}
            />
          ))}
        </div>

        {/* Call to Action */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.3 }}
          className="mt-12 text-center"
        >
          <p className="text-gray-600 mb-6 text-lg">
            Ready to analyze your own privacy policies?
          </p>
          <a
            href="/analyze"
            className="inline-block bg-[#1E3A8A] text-white px-8 py-4 rounded-lg font-bold text-lg hover:bg-[#1e40af] transition-colors shadow-lg hover:shadow-xl"
          >
            Start Analyzing Now
          </a>
        </motion.div>
      </div>

      {/* Detail Modal */}
      <AnimatePresence>
        {selectedPlatform && (
          <DetailModal 
            platform={selectedPlatform}
            onClose={() => setSelectedPlatform(null)}
          />
        )}
      </AnimatePresence>
    </section>
  );
}