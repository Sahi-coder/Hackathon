import { useNavigate } from "react-router";
import { Search, ExternalLink } from "lucide-react";
import { useState } from "react";
import { motion } from "motion/react";
import { mockHistoryData } from "../utils/mockData";

export function HistoryTable() {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState("");

  const filteredData = mockHistoryData.filter((item) =>
    item.url.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getRiskColor = (risk: string) => {
    if (risk === "High") return "text-[#EF4444] bg-[#EF4444]/10";
    if (risk === "Moderate") return "text-[#F59E0B] bg-[#F59E0B]/10";
    return "text-[#10B981] bg-[#10B981]/10";
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-2xl shadow-lg p-6"
    >
      {/* Search Bar */}
      <div className="mb-6">
        <div className="relative">
          <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by URL..."
            className="w-full pl-12 pr-4 py-3 border-2 border-gray-200 rounded-xl focus:border-[#1E3A8A] focus:outline-none transition-colors"
          />
        </div>
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b-2 border-gray-200">
              <th className="text-left py-4 px-4 font-semibold text-[#1E3A8A]">
                Date
              </th>
              <th className="text-left py-4 px-4 font-semibold text-[#1E3A8A]">
                URL
              </th>
              <th className="text-left py-4 px-4 font-semibold text-[#1E3A8A]">
                Score
              </th>
              <th className="text-left py-4 px-4 font-semibold text-[#1E3A8A]">
                Risk Level
              </th>
              <th className="text-left py-4 px-4 font-semibold text-[#1E3A8A]">
                Action
              </th>
            </tr>
          </thead>
          <tbody>
            {filteredData.map((item, index) => (
              <motion.tr
                key={item.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="border-b border-gray-100 hover:bg-gray-50 transition-colors"
              >
                <td className="py-4 px-4 text-gray-600">{item.date}</td>
                <td className="py-4 px-4">
                  <a
                    href={item.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[#1E3A8A] hover:underline flex items-center space-x-1"
                  >
                    <span className="truncate max-w-xs">{item.url}</span>
                    <ExternalLink className="w-3 h-3 flex-shrink-0" />
                  </a>
                </td>
                <td className="py-4 px-4 font-semibold text-[#1E3A8A]">
                  {item.score}%
                </td>
                <td className="py-4 px-4">
                  <span
                    className={`px-3 py-1 rounded-full text-sm font-semibold ${getRiskColor(
                      item.risk
                    )}`}
                  >
                    {item.risk}
                  </span>
                </td>
                <td className="py-4 px-4">
                  <button
                    onClick={() => navigate(`/dashboard/${item.id}`)}
                    className="text-[#1E3A8A] hover:underline font-semibold"
                  >
                    View Report
                  </button>
                </td>
              </motion.tr>
            ))}
          </tbody>
        </table>

        {filteredData.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-500">No results found</p>
          </div>
        )}
      </div>
    </motion.div>
  );
}
