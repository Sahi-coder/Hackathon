import { useNavigate } from "react-router";
import { ChevronDown } from "lucide-react";
import { motion } from "motion/react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export function HeroSection() {
  const navigate = useNavigate();

  return (
    <section className="relative min-h-[90vh] flex items-center justify-center px-4 py-20">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#1E3A8A]/5 to-[#10B981]/5"></div>

      <div className="relative max-w-7xl mx-auto z-10 w-full">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          {/* Left Side - Text Content */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-8"
          >
            <div className="space-y-4">
              <h1 className="text-5xl md:text-6xl font-bold text-gray-900 leading-tight">
                Understand Before You{" "}
                <span className="text-[#1E3A8A]">Agree</span>.
              </h1>
              <p className="text-2xl md:text-3xl font-semibold text-[#10B981]">
                Analyze PolicyLens
              </p>
            </div>
            
            <p className="text-xl text-gray-600 leading-relaxed">
              PolicyLens transforms complex legal agreements into clear, visual
              risk insights. Analyze via URL, PDF, or text in seconds.
            </p>

            <div className="flex flex-col sm:flex-row gap-4">
              <motion.button
                onClick={() => {
                  document.getElementById("how-it-works")?.scrollIntoView({ behavior: "smooth" });
                }}
                className="bg-white text-[#1E3A8A] border-2 border-[#1E3A8A] px-10 py-4 rounded-xl text-lg font-semibold hover:bg-[#1E3A8A] hover:text-white transition-colors"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                Learn More
              </motion.button>
            </div>

            {/* Trust Indicators */}
            <div className="flex flex-wrap gap-6 pt-4">
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-[#10B981] rounded-full"></div>
                <span className="text-sm text-gray-600 font-semibold">Instant Analysis</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-[#10B981] rounded-full"></div>
                <span className="text-sm text-gray-600 font-semibold">Visual Insights</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-[#10B981] rounded-full"></div>
                <span className="text-sm text-gray-600 font-semibold">Multi-Language</span>
              </div>
            </div>
          </motion.div>

          {/* Right Side - Image */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative"
          >
            <div className="relative rounded-2xl overflow-hidden shadow-2xl">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1528746901924-d886b501e255?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxidXNpbmVzcyUyMHByb2Zlc3Npb25hbCUyMHJldmlld2luZyUyMGRvY3VtZW50JTIwcHJpdmFjeSUyMHBvbGljeXxlbnwxfHx8fDE3NzE3NDcxMzl8MA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Professional reviewing privacy policy document"
                className="w-full h-auto"
              />
              {/* Overlay Gradient */}
              <div className="absolute inset-0 bg-gradient-to-tr from-[#1E3A8A]/20 to-transparent"></div>
            </div>

            {/* Floating Stats Card */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.6 }}
              className="absolute -bottom-6 -left-6 bg-white rounded-xl shadow-xl p-6 border border-gray-100"
            >
              <div className="flex items-center space-x-4">
                <div className="bg-[#10B981] w-12 h-12 rounded-full flex items-center justify-center">
                  <span className="text-white text-xl font-bold">✓</span>
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-900">10,000+</p>
                  <p className="text-sm text-gray-600">Policies Analyzed</p>
                </div>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </div>

      {/* Animated Scroll Indicator */}
      <motion.div
        className="absolute bottom-10 left-1/2 transform -translate-x-1/2"
        animate={{ y: [0, 10, 0] }}
        transition={{ duration: 2, repeat: Infinity }}
      >
        <ChevronDown className="w-8 h-8 text-gray-400" />
      </motion.div>
    </section>
  );
}