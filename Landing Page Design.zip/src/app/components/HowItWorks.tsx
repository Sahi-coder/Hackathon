import { Search, Scale, BarChart3 } from "lucide-react";
import { motion } from "motion/react";

const steps = [
  {
    icon: Search,
    title: "Submit",
    description: "Upload a PDF, paste text, or enter a URL to any privacy policy",
  },
  {
    icon: Scale,
    title: "Analyze",
    description: "Our AI examines clauses for risks and potential issues",
  },
  {
    icon: BarChart3,
    title: "Visualize",
    description: "Get a comprehensive dashboard with risk scores and insights",
  },
];

export function HowItWorks() {
  return (
    <section id="how-it-works" className="py-20 px-4 bg-gray-50">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-4xl font-bold text-center text-gray-900 mb-16">
          How It Works
        </h2>
        <div className="grid md:grid-cols-3 gap-8">
          {steps.map((step, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.2 }}
              whileHover={{ y: -10 }}
              className="bg-white rounded-2xl p-8 text-center shadow-lg hover:shadow-xl transition-shadow"
            >
              <div className="bg-[#1E3A8A] w-16 h-16 rounded-xl flex items-center justify-center mx-auto mb-6">
                <step.icon className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">
                {step.title}
              </h3>
              <p className="text-gray-600">{step.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}