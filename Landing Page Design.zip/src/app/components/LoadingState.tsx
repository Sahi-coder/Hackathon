import { Check, Loader2 } from "lucide-react";
import { motion } from "motion/react";
import { useState, useEffect } from "react";

const steps = [
  "Fetching document",
  "Processing content",
  "Identifying risk patterns",
];

export function LoadingState() {
  const [currentStep, setCurrentStep] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentStep((prev) => {
        if (prev < steps.length - 1) {
          return prev + 1;
        }
        return prev;
      });
    }, 1200);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="w-full max-w-2xl">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white rounded-2xl shadow-xl p-12 text-center"
      >
        {/* Animated Spinner */}
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
          className="w-20 h-20 mx-auto mb-8"
        >
          <div className="w-20 h-20 border-4 border-[#1E3A8A] border-t-transparent rounded-full"></div>
        </motion.div>

        <h2 className="text-2xl font-bold text-[#1E3A8A] mb-4">
          Analyzing Policy...
        </h2>
        <p className="text-gray-600 mb-8">Extracting legal clauses</p>

        {/* Progress Steps */}
        <div className="space-y-4 max-w-md mx-auto">
          {steps.map((step, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.3 }}
              className={`flex items-center space-x-3 p-4 rounded-lg ${
                index <= currentStep
                  ? "bg-[#10B981]/10 border-2 border-[#10B981]"
                  : "bg-gray-50"
              }`}
            >
              {index < currentStep ? (
                <div className="bg-[#10B981] rounded-full p-1">
                  <Check className="w-4 h-4 text-white" />
                </div>
              ) : index === currentStep ? (
                <Loader2 className="w-6 h-6 text-[#1E3A8A] animate-spin" />
              ) : (
                <div className="w-6 h-6 border-2 border-gray-300 rounded-full"></div>
              )}
              <span
                className={`font-medium ${
                  index <= currentStep ? "text-[#1E3A8A]" : "text-gray-400"
                }`}
              >
                {step}
              </span>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </div>
  );
}
