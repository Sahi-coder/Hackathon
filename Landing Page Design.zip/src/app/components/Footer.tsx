import { Github } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-[#1E3A8A] text-white py-12 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="grid md:grid-cols-4 gap-8 mb-8">
          <div>
            <h3 className="font-bold mb-4">About</h3>
            <p className="text-gray-300 text-sm">
              PolicyLens helps users understand legal documents through AI-powered analysis.
            </p>
          </div>
          <div>
            <h3 className="font-bold mb-4">Contact</h3>
            <p className="text-gray-300 text-sm">contact@policylens.com</p>
          </div>
          <div>
            <h3 className="font-bold mb-4">GitHub</h3>
            <a
              href="https://github.com"
              className="flex items-center space-x-2 text-gray-300 hover:text-white transition-colors"
            >
              <Github className="w-5 h-5" />
              <span className="text-sm">View Source</span>
            </a>
          </div>
          <div>
            <h3 className="font-bold mb-4">Version</h3>
            <p className="text-gray-300 text-sm">v1.0.0</p>
          </div>
        </div>
        <div className="border-t border-gray-700 pt-8 text-center text-gray-300 text-sm">
          © 2026 PolicyLens. All rights reserved.
        </div>
      </div>
    </footer>
  );
}
