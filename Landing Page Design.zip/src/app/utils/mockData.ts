export const mockAnalysisData = {
  overallScore: 68,
  riskLevel: "moderateRiskPolicy",
  alerts: [
    "highTrackingRisk",
    "extensiveDataSharing",
  ],
  categories: [
    {
      name: "thirdPartySharing",
      score: 45,
      risk: "High",
      impact: -15,
    },
    {
      name: "dataCollection",
      score: 52,
      risk: "High",
      impact: -12,
    },
    {
      name: "securityMeasures",
      score: 75,
      risk: "Moderate",
      impact: -5,
    },
    {
      name: "dataRetention",
      score: 70,
      risk: "Moderate",
      impact: -8,
    },
    {
      name: "changePolicy",
      score: 50,
      risk: "High",
      impact: -10,
    },
    {
      name: "userRights",
      score: 82,
      risk: "Safe",
      impact: 2,
    },
  ],
  clauses: [
    {
      category: "dataSharingClausesDetected",
      items: [
        "shareDataWithPartners",
        "disclosureToAffiliates",
        "shareWithServiceProviders",
      ],
    },
    {
      category: "trackingAndCookies",
      items: [
        "useCookiesTracking",
        "thirdPartyAnalytics",
        "locationDataAdvertising",
      ],
    },
    {
      category: "liabilityLimitations",
      items: [
        "notLiableIndirect",
        "limitedLiability",
        "noWarranties",
      ],
    },
    {
      category: "dataRetentionPolicies",
      items: [
        "retainIndefinitely",
        "dataAfterDeletion",
        "backupRetention",
      ],
    },
    {
      category: "autoRenewalTerms",
      items: [
        "autoRenewal",
        "priceIncreases",
        "complexCancellation",
      ],
    },
  ],
};

export const mockHistoryData = [
  {
    id: "abc123",
    date: "2026-02-20",
    url: "https://twitter.com/privacy",
    score: 68,
    risk: "Moderate",
  },
  {
    id: "def456",
    date: "2026-02-18",
    url: "https://facebook.com/policy",
    score: 52,
    risk: "High",
  },
  {
    id: "ghi789",
    date: "2026-02-15",
    url: "https://google.com/policies/terms",
    score: 85,
    risk: "Safe",
  },
  {
    id: "jkl012",
    date: "2026-02-10",
    url: "https://amazon.com/privacy",
    score: 72,
    risk: "Moderate",
  },
];