import { Navbar } from "../components/Navbar";
import { HeroSection } from "../components/HeroSection";
import { HowItWorks } from "../components/HowItWorks";
import { WhyPolicyLens } from "../components/WhyPolicyLens";
import { Footer } from "../components/Footer";
import { PlatformShowcase } from "../components/PlatformShowcase";

export function LandingPage() {
  return (
    <div className="min-h-screen">
      <Navbar />
      <HeroSection />
      <HowItWorks />
      <PlatformShowcase />
      <WhyPolicyLens />
      <Footer />
    </div>
  );
}