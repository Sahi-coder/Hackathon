import { Navbar } from "../components/Navbar";
import { InputForm } from "../components/InputForm";
import { Footer } from "../components/Footer";

export function AnalyzePage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <div className="flex-1 flex items-center justify-center px-4 py-20">
        <InputForm />
      </div>
      <Footer />
    </div>
  );
}
