import { Navbar } from "../components/Navbar";
import { ScoreGauge } from "../components/ScoreGauge";
import { AlertBox } from "../components/AlertBox";
import { RiskChart } from "../components/RiskChart";
import { RiskCard } from "../components/RiskCard";
import { ClauseAccordion } from "../components/ClauseAccordion";
import { Download } from "lucide-react";
import { motion } from "motion/react";
import { mockAnalysisData } from "../utils/mockData";
import { useLanguage } from "../utils/LanguageContext";

export function DashboardPage() {
  const data = mockAnalysisData;
  const { t } = useLanguage();

  const handleDownloadReport = () => {
    alert("Report download would start here!");
  };

  return (
    <div className="min-h-screen bg-[#F9FAFB]">
      <Navbar />
      <div className="max-w-7xl mx-auto px-4 py-8 space-y-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <h1 className="text-3xl font-bold text-[#1E3A8A] mb-2">
            Policy Analysis Report
          </h1>
          <p className="text-gray-600">
            {t("analyzedOn")} {new Date().toLocaleDateString()}
          </p>
        </motion.div>

        {/* Score and Alert Section */}
        <div className="grid md:grid-cols-2 gap-6">
          <ScoreGauge score={data.overallScore} risk={t(data.riskLevel as any)} />
          <AlertBox alerts={data.alerts.map(alert => t(alert as any))} />
        </div>

        {/* Category Breakdown Chart */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <RiskChart categories={data.categories} />
        </motion.div>

        {/* Risk Category Cards */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <h2 className="text-2xl font-bold text-[#1E3A8A] mb-4">
            Risk Categories
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {data.categories.map((category, index) => (
              <RiskCard key={index} category={category} />
            ))}
          </div>
        </motion.div>

        {/* Clause Explanation Panel */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <ClauseAccordion clauses={data.clauses} />
        </motion.div>

        {/* Download Button */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="flex justify-end"
        >
          <button
            onClick={handleDownloadReport}
            className="flex items-center space-x-2 px-6 py-3 border-2 border-[#1E3A8A] text-[#1E3A8A] rounded-lg hover:bg-[#1E3A8A] hover:text-white transition-all font-semibold"
          >
            <Download className="w-5 h-5" />
            <span>Download Risk Report</span>
          </button>
        </motion.div>
      </div>
    </div>
  );
}