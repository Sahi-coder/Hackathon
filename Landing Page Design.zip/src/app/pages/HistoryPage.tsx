import { Navbar } from "../components/Navbar";
import { Footer } from "../components/Footer";
import { HistoryTable } from "../components/HistoryTable";
import { motion } from "motion/react";

export function HistoryPage() {
  return (
    <div className="min-h-screen bg-[#F9FAFB] flex flex-col">
      <Navbar />
      <div className="flex-1 max-w-7xl mx-auto px-4 py-8 w-full">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-3xl font-bold text-[#1E3A8A] mb-2">
            Analysis History
          </h1>
          <p className="text-gray-600">
            View all your previous policy analyses
          </p>
        </motion.div>
        <HistoryTable />
      </div>
      <Footer />
    </div>
  );
}
