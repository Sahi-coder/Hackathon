import { createBrowserRouter } from "react-router";
import { LandingPage } from "./pages/LandingPage";
import { AnalyzePage } from "./pages/AnalyzePage";
import { DashboardPage } from "./pages/DashboardPage";
import { HistoryPage } from "./pages/HistoryPage";
import { RootLayout } from "./layouts/RootLayout";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: RootLayout,
    children: [
      { index: true, Component: LandingPage },
      { path: "analyze", Component: AnalyzePage },
      { path: "dashboard/:id", Component: DashboardPage },
      { path: "history", Component: HistoryPage },
    ],
  },
]);
